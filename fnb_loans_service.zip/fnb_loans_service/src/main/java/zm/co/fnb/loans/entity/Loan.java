package zm.co.fnb.loans.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name="Loans")
public class Loan
{
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long loan_id;
	 @Column(nullable=false)
	private String firstName;
	 @Column(nullable=false)
	private String lastName;
	 @Column(nullable=false)
	private String number;
	 @Column(nullable=false)
	private String loan_amount;
	 @Column(nullable=false)
	private String employmentType;
	 @Column(nullable=false)
	private String annual_gross;
	 @Column(nullable=false)
	private String idss_number;
	 @Column(nullable=false)
	private String loan_product;
	 @Column(nullable=false)
	private String status;
	 @Column(nullable=false)
	private String due_date;

    public Loan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Loan(Long loan_id, String firstName, String lastName, String number, String loan_amount,
			String employmentType, String annual_gross, String idss_number, String loan_product, String status,
			String due_date) {
		super();
		this.loan_id = loan_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.number = number;
		this.loan_amount = loan_amount;
		this.employmentType = employmentType;
		this.annual_gross = annual_gross;
		this.idss_number = idss_number;
		this.loan_product = loan_product;
		this.status = status;
		this.due_date = due_date;
	}

	public Long getLoan_id() {
		return loan_id;
	}

	public void setLoan_id(Long loan_id) {
		this.loan_id = loan_id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getLoan_amount() {
		return loan_amount;
	}

	public void setLoan_amount(String loan_amount) {
		this.loan_amount = loan_amount;
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public String getAnnual_gross() {
		return annual_gross;
	}

	public void setAnnual_gross(String annual_gross) {
		this.annual_gross = annual_gross;
	}

	public String getIdss_number() {
		return idss_number;
	}

	public void setIdss_number(String idss_number) {
		this.idss_number = idss_number;
	}

	public String getLoan_product() {
		return loan_product;
	}

	public void setLoan_product(String loan_product) {
		this.loan_product = loan_product;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDue_date() {
		return due_date;
	}

	public void setDue_date(String due_date) {
		this.due_date = due_date;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Loan [loan_id=" + loan_id + ", firstName=" + firstName + ", lastName=" + lastName + ", number=" + number
				+ ", loan_amount=" + loan_amount + ", employmentType=" + employmentType + ", annual_gross="
				+ annual_gross + ", idss_number=" + idss_number + ", loan_product=" + loan_product + ", status="
				+ status + ", due_date=" + due_date + "]";
	}


}
