package zm.co.fnb.loans.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import zm.co.fnb.loans.entity.Loan;

@Repository
public interface LoanRepository extends JpaRepository<Loan, Long>{
	Loan findByNumber(String number);

}
