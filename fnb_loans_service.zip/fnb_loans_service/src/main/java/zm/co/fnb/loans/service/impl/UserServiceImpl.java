package zm.co.fnb.loans.service.impl;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import zm.co.fnb.loans.dto.LoanDto;
import zm.co.fnb.loans.dto.UserDto;
import zm.co.fnb.loans.entity.Loan;
import zm.co.fnb.loans.entity.Role;
import zm.co.fnb.loans.entity.User;
import zm.co.fnb.loans.repository.LoanRepository;
import zm.co.fnb.loans.repository.RoleRepository;
import zm.co.fnb.loans.repository.UserRepository;
import zm.co.fnb.loans.service.UserService;

import java.sql.Date;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    private RoleRepository roleRepository;
    private PasswordEncoder passwordEncoder;
    private LoanRepository loanRepository;
    
    public UserServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           LoanRepository loanRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.loanRepository = loanRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void saveUser(UserDto userDto) {
        User user = new User();
        user.setName(userDto.getFirstName() + " " + userDto.getLastName());
        user.setNumber(userDto.getNumber());

        //encrypt the password once we integrate spring security
        //user.setPassword(userDto.getPassword());
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        Role role = roleRepository.findByName("ROLE_ADMIN");
        if(role == null){
            role = checkRoleExist();
        }
        user.setRoles(Arrays.asList(role));
        userRepository.save(user);
    }

    @Override
    public User findByNumber(String number) {
        return userRepository.findByNumber(number);
    }

    @Override
    public List<UserDto> findAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream().map((user) -> convertEntityToDto(user))
                .collect(Collectors.toList());
    }

    private UserDto convertEntityToDto(User user){
        UserDto userDto = new UserDto();
        String[] name = user.getName().split(" ");
        userDto.setFirstName(name[0]);
        userDto.setLastName(name[1]);
        userDto.setNumber(user.getNumber());
        return userDto;
    }

    private Role checkRoleExist() {
        Role role = new Role();
        role.setName("ROLE_ADMIN");
        return roleRepository.save(role);
    }

	@Override
	public void requestLoan(Loan loan) {
		System.out.println(loan.toString());
		Loan saved = loanRepository.save(loan);
		
		if (saved != null) {
			System.out.println("Loan Saved");
		}else{
			System.out.println("Loan Not Saved");
		}
		
	}

	@Override
	public List<Loan> findAllLoans() {
		List<Loan> loans = loanRepository.findAll();

		return loans;
	}
}
