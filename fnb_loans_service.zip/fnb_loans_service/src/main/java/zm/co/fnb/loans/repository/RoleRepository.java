package zm.co.fnb.loans.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import zm.co.fnb.loans.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Role findByName(String name);
}
