package zm.co.fnb.loans.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import zm.co.fnb.loans.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByNumber(String number);
}
