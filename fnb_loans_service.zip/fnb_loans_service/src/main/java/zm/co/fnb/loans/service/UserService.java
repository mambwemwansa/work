package zm.co.fnb.loans.service;

import java.util.List;

import jakarta.validation.Valid;
import zm.co.fnb.loans.dto.LoanDto;
import zm.co.fnb.loans.dto.UserDto;
import zm.co.fnb.loans.entity.Loan;
import zm.co.fnb.loans.entity.User;

public interface UserService {
	
    void saveUser(UserDto userDto);
    User findByNumber(String number);
    List<UserDto> findAllUsers();
    public void requestLoan(Loan loan);
    public List<Loan> findAllLoans();
}
