package zm.co.fnb.loans.controller;

import jakarta.validation.Valid;
import zm.co.fnb.loans.dto.UserDto;
import zm.co.fnb.loans.entity.Loan;
import zm.co.fnb.loans.entity.User;
import zm.co.fnb.loans.service.UserService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;

@Controller
public class AuthController {

    private UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("index")
    public String home(){
        return "index";
    }

    @GetMapping("/login")
    public String loginForm() {

        System.out.println("LOAN SERVED!!!!! +++++ loginForm");
        return "login";
    }

    // handler method to handle user registration request
    @GetMapping("register")
    public String showRegistrationForm(Model model){
        UserDto user = new UserDto();
        model.addAttribute("user", user);
        return "register";
    }

    // handler method to handle register user form submit request
    @PostMapping("/register/save")
    public String registration(@Valid @ModelAttribute("user") UserDto user,
                               BindingResult result,
                               Model model){
        User existing = userService.findByNumber(user.getNumber());
        if (existing != null) {
            result.rejectValue("number", null, "There is already an account registered with that number");
        }
        if (result.hasErrors()) {
            model.addAttribute("user", user);
            return "register";
        }
        userService.saveUser(user);
        return "redirect:/register?success";
    }

    @GetMapping("/users")
    public String listRegisteredUsers(Model model){
        List<UserDto> users = userService.findAllUsers();
        List<Loan> loans = userService.findAllLoans();

        System.out.println("LOAN SERVED!!!!! ++++++ listRegisteredUsers");
        System.out.println(loans.size());
        


        model.addAttribute("users", users);
        model.addAttribute("loans", loans);
        return "users";
    }
    
    // handler method to handle register user form submit request
    @PostMapping("/users/requestLoan")
    public String requestLoan(@Valid @ModelAttribute("loan") Loan loan,
                               BindingResult result,
                               Model model){
        List<UserDto> users = userService.findAllUsers();
    	
    	loan.setFirstName(users.get(0).getFirstName());
		loan.setLastName(users.get(0).getLastName());
		loan.setNumber(users.get(0).getNumber());
		
		loan.setStatus("pending approval");
		LocalDate payback_date; 
		if (loan.getDue_date().equals("days_30")) {
			
			payback_date=LocalDate.now().plusDays(30);
			
		}else if(loan.getDue_date().equals("days_60")) {
			
			payback_date= LocalDate.now().plusDays(60);
			
		}else {
			payback_date=LocalDate.now().plusDays(90);
		}
		loan.setDue_date(payback_date.toString());
		

        System.out.println("LOAN SERVED!!!!! +++++ requestLoan=----="+loan.toString());
//        User existing = userService.findByNumber(loan.getNumber());
//        if (existing != null) {
//            result.rejectValue("number", null, "There is already an account registered with that number");
//        }
//        if (result.hasErrors()) {
//            model.addAttribute("loan", loan);
//            return "users";
//        }
        userService.requestLoan(loan);

        List<Loan> loans = userService.findAllLoans();
        model.addAttribute("users", users);
        model.addAttribute("loans", loans);
        return "redirect:/users?success";
    }
}
