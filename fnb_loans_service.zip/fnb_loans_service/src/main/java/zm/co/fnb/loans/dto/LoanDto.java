package zm.co.fnb.loans.dto;

import java.sql.Date;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

public class LoanDto {
	private Long loan_id;
	@NotEmpty
	private String firstName;
	@NotEmpty
	private String lastName;
	@NotEmpty(message = "Phone Number should not be empty")
	private String number;
	@NotEmpty(message = "Loan Amount should not be empty")
	private String loan_amount;
	@NotEmpty(message = "Emplyment Type should not be empty")
	private String employmentType;
	@NotEmpty(message = "Annuel Gross should not be empty")
	private String annual_gross;
	@NotEmpty(message = "id or social security number should not be empty")
	private String idss_number;
	@NotEmpty
	private String loan_product;
	@NotEmpty
	private String status;
	@NotEmpty
	private Date due_date;

	public LoanDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoanDto(Long loan_id, @NotEmpty String firstName, @NotEmpty String lastName,
			@NotEmpty(message = "Phone Number should not be empty") String number,
			@NotEmpty(message = "Loan Amount should not be empty") String loan_amount,
			@NotEmpty(message = "Emplyment Type should not be empty") String employmentType,
			@NotEmpty(message = "Annuel Gross should not be empty") String annual_gross,
			@NotEmpty(message = "id or social security number should not be empty") String idss_number,
			@NotEmpty String loan_product, @NotEmpty String status, @NotEmpty Date due_date) {
		super();
		this.loan_id = loan_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.number = number;
		this.loan_amount = loan_amount;
		this.employmentType = employmentType;
		this.annual_gross = annual_gross;
		this.idss_number = idss_number;
		this.loan_product = loan_product;
		this.status = status;
		this.due_date = due_date;
	}

	public Long getLoan_id() {
		return loan_id;
	}

	public void setLoan_id(Long loan_id) {
		this.loan_id = loan_id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getLoan_amount() {
		return loan_amount;
	}

	public void setLoan_amount(String loan_amount) {
		this.loan_amount = loan_amount;
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public String getAnnual_gross() {
		return annual_gross;
	}

	public void setAnnual_gross(String annual_gross) {
		this.annual_gross = annual_gross;
	}

	public String getIdss_number() {
		return idss_number;
	}

	public void setIdss_number(String idss_number) {
		this.idss_number = idss_number;
	}

	public String getLoan_product() {
		return loan_product;
	}

	public void setLoan_product(String loan_product) {
		this.loan_product = loan_product;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDue_date() {
		return due_date;
	}

	public void setDue_date(Date due_date) {
		this.due_date = due_date;
	}

	@Override
	public String toString() {
		return "LoanDto [loan_id=" + loan_id + ", firstName=" + firstName + ", lastName=" + lastName + ", number="
				+ number + ", loan_amount=" + loan_amount + ", employmentType=" + employmentType + ", annual_gross="
				+ annual_gross + ", idss_number=" + idss_number + ", loan_product=" + loan_product + ", status="
				+ status + ", due_date=" + due_date + "]";
	}

}
