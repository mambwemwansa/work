var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
var output1 = document.getElementById("demo1");
var tenor = document.getElementById("select_id");
var output2 = document.getElementById("demo3");
var output3 = document.getElementById("demo2");
var select = document.getElementById('select');

var someDate = new Date();

  
output.innerHTML = slider.value;
output1.innerHTML =  new Date().toLocaleDateString() ;
output2.innerHTML = (slider.value/1).toFixed(2);
output3.innerHTML = (slider.value/1).toFixed(2);


select.addEventListener('change', function handleChange(event) {
    // get selected VALUE even outside event handler
    //console.log(select.options[select.selectedIndex].value);
    var duration = select.options[select.selectedIndex].value;
    
    var slidervalue = document.getElementById("myRange").value;
    var someDate = new Date();
    if (duration === "30") {
        someDate.setTime(someDate.getTime() +  (30 * 24 * 60 * 60 * 1000));
        output1.innerHTML =  someDate.toLocaleDateString();
        output3.innerHTML = ((parseInt(slidervalue)+(slider.value*0.15))/1).toFixed(2);
    }
    if (duration === "60") {
        someDate.setTime(someDate.getTime() +  (60 * 24 * 60 * 60 * 1000));
        output1.innerHTML =  someDate.toLocaleDateString(); 
        output3.innerHTML = ((parseInt(slidervalue)+(slider.value*0.30))/2).toFixed(2);
    }
    if (duration === "90") {
        someDate.setTime(someDate.getTime() +  (90 * 24 * 60 * 60 * 1000));
        output1.innerHTML =  someDate.toLocaleDateString();
        output3.innerHTML = ((parseInt(slidervalue)+(slider.value*0.45))/3).toFixed(2);
    }
    
    // get selected TEXT in or outside event handler
    console.log(select.options[select.selectedIndex].text);
});
$("#minus").click(function(event) {
    zoom("out");

  });
  
  $("#plus").click(function(event) {
    zoom("in");
  });
  
  $("#myRange").on('input change', function(event) {
    $('#output').text($(event.currentTarget).val()); 
    var select = document.getElementById('select');
        var duration = select.value;
        var slidervalue= $(event.currentTarget).val();

        if (duration === "30") {
            output.innerHTML = this.value;;
            output3.innerHTML = ((parseInt(slidervalue)+(slider.value*0.15))/1).toFixed(2);
        }
        if (duration === "60") {
            output.innerHTML = this.value;
            output3.innerHTML = ((parseInt(slidervalue)+(slider.value*0.30))/2).toFixed(2);
        }
        if (duration === "90") {
            output.innerHTML = this.value;
            output3.innerHTML = ((parseInt(slidervalue)+(slider.value*0.45))/3).toFixed(2);
        }
  });
  
  function zoom(direction) {
    var slider = document.getElementById("myRange");
    var step = parseInt(slider.attr('step'), 1);
    var currentSliderValue = parseInt(slider.val(), 1);
    var newStepValue = currentSliderValue + step;
    
  
    if (direction === "out") {
      newStepValue = currentSliderValue - step;
      
    console.log( "out");
    } else { 
        console.log( "in");
      newStepValue = currentSliderValue + step;
    }
  
    slider.val(newStepValue).change();
  };